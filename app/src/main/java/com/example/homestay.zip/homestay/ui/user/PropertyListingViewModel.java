package com.example.homestay.ui.user;

public class PropertyListingViewModel {
}
